﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace QueueConcorrent
{
    public static class ExecucaoFila
    {
        public static ConcurrentQueue<string> _datahora = new ConcurrentQueue<string>();

        static ExecucaoFila()
        {
            Thread backgroundThread = new Thread(LerFila);
            backgroundThread.Start();

        }


        public static void Enfileirar(string datahora)
        {
            Task.Factory.StartNew(() => { Thread.Sleep(10000); ExecucaoFila._datahora.Enqueue(datahora); });
        }


        private static void LerFila()
        {
            while (true)
            {
                if (_datahora.Count == 0) Thread.Sleep(250);
                else
                {
                    string ItemFila;
                    if (_datahora.TryDequeue(out  ItemFila))
                    {
                        GravarLog(ItemFila);
                    }
                }
            }
        }


        public static void GravarLog(string StringErro)
        {
            var nomeArquivo = @"\" + DateTime.Now.Year.ToString();
            nomeArquivo += DateTime.Now.Month.ToString();
            nomeArquivo += DateTime.Now.Day.ToString();

            var Diretorio = @"c:\Projetos\pasta\" + StringErro + ".txt";// ConfigurationManager.AppSettings["DiretorioLog"].ToString();
            //Exemplo @"c:\Projetos\"+nomeArquivo+".txt"
            var Diretorio_salvar_ArquivoSaida = Diretorio + StringErro + ".txt";
            if (!Directory.Exists(Diretorio))
                Directory.CreateDirectory(Diretorio);

            using (FileStream ArquivoSaida = File.Create(Diretorio_salvar_ArquivoSaida))
            {
                using (StreamWriter Escrever_ArquivoSaida = new StreamWriter(ArquivoSaida))
                {
                    Escrever_ArquivoSaida.WriteLine(StringErro);
                }
            }
        }


    }
}
