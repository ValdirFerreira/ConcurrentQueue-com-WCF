﻿using QueueConcorrent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SiteConcurrentQueue
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Executar_Click(object sender, EventArgs e)
        {
            resposta.Text = string.Empty;
            Random Random = new Random();

            ExecucaoFila.Enfileirar(Random.Next().ToString() + resposta.Text);

            resposta.Text = "OK OK OK ";
        }
    }
}